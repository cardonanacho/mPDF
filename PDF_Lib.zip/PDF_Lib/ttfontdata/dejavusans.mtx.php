<?php
$name='DejaVuSans';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-1021 -415 1681 1167]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='/var/www/html/crm.gruposangerman.com/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/DejaVuSans.ttf';
$TTCfontID='0';
$originalsize=633604;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusans';
$panose=' 0 0 2 b 6 3 3 8 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>