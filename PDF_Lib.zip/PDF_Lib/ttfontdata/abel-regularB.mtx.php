<?php
$name='Abel-Regular';
$type='TTF';
$desc=array (
  'Ascent' => 979.0,
  'Descent' => -295.0,
  'CapHeight' => 700.0,
  'Flags' => 4,
  'FontBBox' => '[-50 -295 950 979]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 1000.0,
);
$up=-180;
$ut=40;
$ttffile='/var/www/html/crm.gruposangerman.com/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/Abel-Regular.ttf';
$TTCfontID='0';
$originalsize=33184;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='abel-regularB';
$panose=' 0 0 2 0 5 6 3 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>