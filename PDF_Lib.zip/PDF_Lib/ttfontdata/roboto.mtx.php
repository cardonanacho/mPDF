<?php
$name='Roboto-Light';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -244.0,
  'CapHeight' => 711.0,
  'Flags' => 4,
  'FontBBox' => '[-734 -271 1138 1056]',
  'ItalicAngle' => 0.0,
  'StemV' => 71.0,
  'MissingWidth' => 443.0,
);
$up=-73;
$ut=49;
$ttffile='/var/www/html/crm.gruposangerman.com/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/Roboto-Light.ttf';
$TTCfontID='0';
$originalsize=167000;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='roboto';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>