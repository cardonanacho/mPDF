<?php
$name='PTSans-NarrowBold';
$type='TTF';
$desc=array (
  'Ascent' => 1018.0,
  'Descent' => -276.0,
  'CapHeight' => 700.0,
  'Flags' => 262148,
  'FontBBox' => '[-422 -273 1011 1009]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 750.0,
);
$up=-75;
$ut=50;
$ttffile='/var/www/html/crm.gruposangerman.com/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/PTSansNarrow-Bold.ttf';
$TTCfontID='0';
$originalsize=316044;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ptsansB';
$panose=' 8 2 2 b 7 6 2 2 3 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>