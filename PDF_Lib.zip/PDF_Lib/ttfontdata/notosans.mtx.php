<?php
$name='NotoSansMono-Light';
$type='TTF';
$desc=array (
  'Ascent' => 1069.0,
  'Descent' => -293.0,
  'CapHeight' => 714.0,
  'Flags' => 5,
  'FontBBox' => '[-616 -389 1800 1229]',
  'ItalicAngle' => 0.0,
  'StemV' => 71.0,
  'MissingWidth' => 600.0,
);
$up=-100;
$ut=50;
$ttffile='/var/www/html/crm.gruposangerman.com/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/NotoSansMono-Light.ttf';
$TTCfontID='0';
$originalsize=353772;
$sip=false;
$smp=true;
$BMPselected=false;
$fontkey='notosans';
$panose=' 0 0 2 b 5 9 4 5 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>