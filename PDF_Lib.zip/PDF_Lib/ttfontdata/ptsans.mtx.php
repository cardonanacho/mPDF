<?php
$name='PTSans-Narrow';
$type='TTF';
$desc=array (
  'Ascent' => 1018.0,
  'Descent' => -276.0,
  'CapHeight' => 700.0,
  'Flags' => 4,
  'FontBBox' => '[-394 -245 905 993]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 750.0,
);
$up=-75;
$ut=50;
$ttffile='/var/www/html/crm.gruposangerman.com/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/PTSansNarrow-Regular.ttf';
$TTCfontID='0';
$originalsize=234208;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ptsans';
$panose=' 8 2 2 b 5 6 2 2 3 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>