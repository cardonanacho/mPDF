<?php
$name='ocrb10';
$type='TTF';
$desc=array (
  'Ascent' => 938.0,
  'Descent' => -335.0,
  'CapHeight' => 938.0,
  'Flags' => 4,
  'FontBBox' => '[-87 -335 782 938]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 723.0,
);
$up=-100;
$ut=50;
$ttffile='/var/www/html/nuevaversion/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/ocrb10.ttf';
$TTCfontID='0';
$originalsize=23112;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ocrb';
$panose=' 0 0 2 0 5 9 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>