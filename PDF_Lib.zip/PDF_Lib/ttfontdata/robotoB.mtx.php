<?php
$name='Roboto-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -244.0,
  'CapHeight' => 711.0,
  'Flags' => 262148,
  'FontBBox' => '[-727 -271 1191 1056]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 443.0,
);
$up=-73;
$ut=49;
$ttffile='/var/www/html/crm.gruposangerman.com/modules/AOS_PDF_Templates/PDF_Lib/ttfonts/Roboto-Bold.ttf';
$TTCfontID='0';
$originalsize=167336;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='robotoB';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>